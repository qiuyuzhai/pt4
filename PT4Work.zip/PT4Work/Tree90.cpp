#include "pt4.h"
using namespace std;

void Solve()
{
    Task("Tree90");
    PNode CreateNode(PNode p)
    {
        if (p==NULL)
        return NULL;
         
    }

}
