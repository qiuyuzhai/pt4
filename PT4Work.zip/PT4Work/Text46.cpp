#include "pt4.h"
using namespace std;

void Solve()
{
    Task("Text46");

}
