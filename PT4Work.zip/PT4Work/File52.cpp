#include "pt4.h"
using namespace std;

void Solve()
{
    Task("File52");

}
