#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray79");
    int n;
    

}
