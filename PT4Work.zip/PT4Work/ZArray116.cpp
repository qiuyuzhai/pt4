#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray116");
    int n;
    pt >> n;
    int a[10],b[10],c[10];
    for(int i=0;i<n;++i)
    {
        pt >> a[10];
    }

}
