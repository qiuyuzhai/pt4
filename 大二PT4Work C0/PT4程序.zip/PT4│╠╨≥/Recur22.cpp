#include "pt4.h"
#include <iostream>
#include <string>
#include <stack>
using namespace std;
stack<char> st;
int MaxOrMin(const char* s)
{
	for (int i = strlen(s) - 1; i >= 0; i--)
	{
		if (s[i] == ')' || s[i] >= '0' && s[i] <= '9')
		{
			st.push(s[i]);
		}
		else if (s[i] == '(')
		{
			if (s[i - 1] == 'm')
			{
				int min = st.top() - '0';
				st.pop();
				while (st.top() != ')')
				{
					if (st.top() - '0' < min)
					{
						min = st.top() - '0';
						st.pop();
					}
					else
					{
						st.pop();
					}
				}
				st.pop();
				st.push(min + '0');
			}
			else if (s[i - 1] == 'M')
			{
				int max = st.top() - '0';
				st.pop();
				while (st.top() != ')')
				{
					if (st.top() - '0' > max)
					{
						max = st.top() - '0';
						st.pop();
					}
					else
					{
						st.pop();
					}
				}
				st.pop();
				st.push(max + '0');
			}
		}
	}
	return st.top() - '0';
}

void Solve()
{
    Task("Recur22");
    string s;
	pt >> s;
	pt << MaxOrMin(s.c_str());

}


