#include "pt4.h"
using namespace std;

int m;

void fun(PNode p1,int n){
    Show(p1->Data);
    Show(n);
    if(n>m){
        m=n;
    }
    if(p1->Next){
        fun(p1->Next,n);
    }
    if(p1->Right)
        fun(p1->Right,n);
    if(p1->Left)
        fun(p1->Left,n+1);    
}

void Solve()
{
    Task("Tree88");
    PNode p1;
    pt >> p1;
    fun(p1,0);
    pt << m;
}
