#include "pt4.h"
#include <iostream>
using namespace std;

void Solve()
{
    Task("ZMatrix25");
{

	int M,N;
	double a[100][100];
	pt >> M;
	pt >> N;

	for (int i=0; i<M; i++)
	{
		for (int j=0; j<N; j++)
		{
			pt >> a[i][j];
		}
	}

	double sum = 0.0f;
	int maXindex = 0;
	for (int i=0; i<M; i++)
	{
		double f = 0.0;
		for (int j=0; j<N; j++)
		{
			f += a[i][j];
		}
		if (f > sum)
		{
			sum = f;
			maXindex = i;
		}
	}

	pt << maXindex;
	pt << sum;


}
}