# temp_str = input("input:");
# print(temp_str)

'''
String 3。 给定一个字符 C。输出两个字符，第一个字符在码表中字符 C 之前，第二个字符在字符 C 之后。
'''
def test_03():
    print("请输入一个字符:")
    temp_str = input("")
    index = ord(temp_str)
 #   print(index)
    print("前一个字符为："+chr(index-1))
    print("后一个字符串："+chr(index+1))


'''
string 11。 给定一个非空字符串 S在每个字符中间插入一个空格，输出一个包含字符串 S 的字符串
'''    
def test_string_11():
    print("请给出一个非空字符串")
    temp_str = input("")
    
    print(temp_str)

    d=list(temp_str)
    temp_str_length = len(d)
    print(temp_str_length)

    target_str = ''
    for i in range(0,temp_str_length-1):
        #print(i)
        target_str = target_str + d[i] + " "
    print(target_str+d[temp_str_length-1])

'''

string 22 给定一个正整数的字符串。 打印这个字符串中的数字总和
''' 
def test_string_22():
    print("请给出一个正整数的字符串")
    temp_str = input("")
    d=list(temp_str)    
    result = 0
    for i in d:
        result = result + int(i)
    print(result)
    
'''    
string 28。 给定一个字符 C 和一个字符串 S。将字符串 S 中出现的字符 C 加倍。
'''
def test_string_28():
        print("请输入一个字符")
        temp_char = input("")        
        print("请输入字符串")
        temp_str = input("")
        d = list(temp_str)
        result = ""
        for i in d:
            if temp_char == i :
                result = result + i + i
            else: 
                result = result + i
        print(result)


'''
string34. 给出了第 S 和 S0 两个字符串。 从字符串 S 中删除与 S0 匹配的最后一个子字符串。
 如果没有匹配的子字符串，则输出字符串 S 保持不变
'''
def test_string_34():
    print("请输入第一个字符串")
    temp_str1 = input("")
    print("请输入第二个字符串")
    temp_str2 = input("")
    
    result = ''
    # 先判断长度，第二个字符串长度大于第一个字符串
    if len(temp_str2) > len(temp_str1):
        result = temp_str1
    else: # 处理正常情况
         str2_length = len(temp_str2)
         str1_length = len(temp_str1)
         can_search_count = str1_length - str2_length + 1
         can_match = 0
         last_match_index = 0
         for i in range(0,can_search_count):
            #print(i)
            current_str  = temp_str1[i:i+str2_length]
            if(current_str == temp_str2):
               can_match = 1
               last_match_index = i
       
         if(can_match == 1):
            result = temp_str1[0:last_match_index] + temp_str1[last_match_index+str2_length:]
         else:
            result = temp_str1
    print(result)
    
    
    







'''
string48 给定一个字符串，该字符串由以大写字母输入并用空格（一个或多个）分隔的俄语单词组成。
 将所有后续出现的第一个字母（单词的首字母）替换为“.”来替换字符串中的每个字母。
 例如，单词“MINIMUM”应转换为“MINI.U.”(后面两个M都变成“.”) 但不要更改单词之间的空格数。
'''
def test_string_48():
    print("请给一个字符串")
    temp_str = input("");
    
    word = 0  #满足非空格字符串的个数
    current_first_word = '' #记录当前单词的首字母
                        
    
    target_str = ""
    for c in temp_str:
        if c == ' ':
            word = 0
        else:
            word = word + 1
        if (word == 1):
            current_first_word = c
            
        if(current_first_word == c and word > 1):
            target_str = target_str + "."
        else:
            target_str = target_str + c         
    print(target_str)
    


'''
string 52。 给定一个俄语字符串句子。 转换字符串，使每个单词都以大写字母开头。 
（单词是一组不包含空格并由空格或字符串的开头/结尾分隔的字符。） 不以字母开头的单词不更改。
'''   
def test_string_52():
    print("请给一个字符串")
    temp_str = input("")
    word = 0  #满足非空格字符串转换条件
    
    target_str = ""
    for c in temp_str:
        #print("此时c为:"+c)
        #print("此时word为:")
        #print(word)
        if c == ' ':
            word = 0
        else:
            word = word + 1
        
        if (ord(c) >= ord('a') and ord(c) <= ord('z') and word == 1):
            target_str = target_str + chr(ord(c)-32)
        else:
            target_str = target_str + c 
                  
    print(target_str)            
'''
string 59。 给定一个包含文件全名的字符串，即驱动器名称、目录列表（路径）、名称本身和扩展名。 从此行中提取文件的扩展名（不带前面的点）。
'''
def test_string_59():
    print("请给定一个文件全名的字符串")
    path = input("")
    result = path.split(".")
    print("result:")
    print(result[len(result)-1])
    
        
'''
String 63。 给定一个俄语句子字符串和一个数字 K (0 < K < 10)。 通过将每个字母循环替换为相同大小写的字母来加密字符串，
替换的字母位于字母表中加密字母之后的第 K 个位置
（例如，对于 K = 2，“a”将转到“c”，“b” 到“d”，等等）。 
不要更改标点符号和空格。
'''
def test_string_63():
    print("字符串")
    temp_str = input("")
    print("一个数字K,0<K<10")
    temp_pos = input("")
    while(int(temp_pos) > 10 or int(temp_pos) <= 0):
        print("输入异常，请再次输入一个数字K,0<K<10")
        temp_pos = input("")
    d = list(temp_str)
    result = ''
    for i in d:
        if (ord(i) >= ord("A") and ord(i) <= ord("z")):
            result = result + chr(ord(i)+ int(temp_pos))
        else:
            result = result + i
    print(result)
        
        
'''
string 68。 给你一个包含数字和小写拉丁字母的字符串。
 如果字符串中的字母按照字母顺序排列，则输出0； 
 否则输出违反字母顺序的字符串的第一个字符的编号。
'''  

def test_string_68():
    print("请输入一个包含数字和小写拉丁字母的字符串")
    temp_str = input("")
    d = list(temp_str)
    start_assic = ord("a")
    end_assic = ord("z")
    current_index = 0
    current_max_assic = 0
    is_order_flag = True
    for i in d:
        current_i_assic = ord(i)
        current_index = current_index + 1
        if(current_i_assic <= end_assic and current_i_assic >= start_assic):
            #print(str(i)+"#"+str(current_i_assic))
            if current_i_assic >= current_max_assic:
                current_max_assic = current_i_assic
                pass
            else:
                is_order_flag = False
                break
    if is_order_flag == False:
        print(current_index)
    else:
        print(0)
 
def main():

#    test_03()
#     test_string_11()
#    test_string_22()
#     test_string_28()
#    test_string_63()
#    test_string_68()
#    test_string_59()
#    test_string_52()
#    test_string_48()
    test_string_34()
    

if __name__ == "__main__":
        main()
        
        
        