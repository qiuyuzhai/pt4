#include "pt4.h"
#include <stack>
#include <string>
#include <iostream>
using namespace std;

void Solve()
{
    Task("String70");
	string s;
	int flag = 1;
	stack<char> st1;
	stack<char> st2;
	stack<char> st3;
	pt >> s;
	for (int i = 0; i < s.size(); i++)
	{
		if (s[i] == '(' || s[i] == '{' || s[i] == '[')
		{
			if (s[i] == '(')
				st1.push(s[i]);
			else if (s[i] == '{')
				st2.push(s[i]);
			else
				st3.push(s[i]);
		}
		else if (s[i] == ')' || s[i] == '}' || s[i] == ']')
		{
			if (s[i] == ')')
			{
				if (!st1.empty())
				{
					st1.pop();
				}
				else
				{
					pt << i + 1;
					flag = 0;
					break;
				}
			}
			else if (s[i] == '}')
			{
				if (!st2.empty())
				{
					st2.pop();
				}
				else
				{
					pt << i + 1;
					flag = 0;
					break;
				}
			}
			else if (s[i] == ']')
			{
				if (!st3.empty())
				{
					st3.pop();
				}
				else
				{
					pt << i + 1;
					flag = 0;
					break;
				}
			}
		}
	}
	if (flag)
	{
		if (!st1.empty() || !st2.empty() || !st3.empty())
			pt << -1;
		else
			pt << 0;
	}
}
