#include "pt4.h"
#include <string>
#include <fstream>
#include <iostream>
using namespace std;
using namespace std;

void Solve()
{
    Task("Text29");
	string s;
	string max;
	ifstream file;
	string name;
	pt >> name;

	file.open(name);
	while (file >> s)
	{
		if (s.size() > max.size())
		{
			max = s;
		}
	}
	pt << max;
	file.close();

}
