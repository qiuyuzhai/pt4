#include "pt4.h"
using namespace std;

void out(PNode p)
{
    if (p==NULL)
    return;
    int d=p->Data;
    p=p->Left;
    out(p);
    pt<<d;
    while(p!=NULL)
    {
        p=p->Right;
        out(p);
    }
}

void Solve()
{
    Task("Tree92");
    out(GetNode());
}
