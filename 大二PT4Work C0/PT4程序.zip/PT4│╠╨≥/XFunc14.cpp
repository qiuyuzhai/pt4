#include "pt4.h"
#include<iostream>
using namespace std;
	int DigitCount(int K)
    {
	int cnt=0;
while(K/10!=0)
{
K=K/10;
cnt++;
}
cnt=cnt+1;
return cnt;
 }

void Solve()
{
    Task("XFunc14");
    int a,b,c,d,e,f,g,h,i,j;
    pt>>a>>b>>c>>d>>e;
   f=DigitCount(a);
   g=DigitCount(b);
   h=DigitCount(c);
   i=DigitCount(d);
   j=DigitCount(e);
pt<<f<<g<<h<<i<<j;
}