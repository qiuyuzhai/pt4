#include "pt4.h"
#include <fstream>
#include <cmath>
using namespace std;
void Solve()
{
    Task("Text48");
    ifstream f(GetString());
    ofstream f1(GetString(), ios::binary);
    int cnt = 0;
    while (true)
    {
        double a;
        f >> a;
        if (f.eof())
            break;
        if (round(a) == a)
        {
            cnt++; 
            int b;
            b=a;
            Show(b);
            f1.write ((char *)&b,4);
        }
}
Show(cnt);
f.close();
}
