#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZMatrix90");
float arr[100][100];
	int M;
	pt >> M;

	for (int i=0; i<M; i++)
	{
		for (int j=0; j<M; j++)
		{
			pt >> arr[i][j];
		}
	}

	for (int i=0; i<M; i++)
	{
		int N = M-i-1;
		for (int j=N; j<M; j++)
		{
			arr[i][j] = 0.00f;
		}

	}

	for (int i=0; i<M; i++)
	{
		for (int j=0; j<M; j++)
		{
			pt << arr[i][j];
		}

	}
	
}
