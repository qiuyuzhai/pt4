#include<iostream>
#include<cmath>
using namespace std;

bool XFunc12_IsPowerN(int K, int N)
{
	while (K != N)
	{
		if (K % N != 0) return false;
		else K /= N;
	}
	return true;
}

bool XFunc16_IsPalindrome(int K)
{
	int K1 = K;
	int K2 = 0;
	while (K1)
	{
		K2 = K2 * 10 + K1 % 10;
		K1 /= 10;
	}
	if (K2 == K) return true;
	return false;
}
void XFunc22_PowerA3(double& A)
{
	A = A * A * A;
}

double XFunc44_Arctg1(double x, double e)
{
	int k = 1;
	double arg = 0;
	for (int i = 1;; i += 2)
	{
		double k1 = pow(x, i) / i;
		if (k1 <= e) break;
		arg += k1 * k;
		k = -k;
	}
	return arg;
}

int XFunc46_GCD2(int A, int B)
{
	if (B == 0) return A;
	else return XFunc46_GCD2(B, A % B);
}

void ZSeries5()
{
	int N, tot = 0;
	cin >> N;
	double a[100];
	for (int i = 0; i < N; i++)cin >> a[i];
	for (int i = 0; i < N; i++) {
		int k = a[i] > 0 ? floor(a[i]) : ceil(a[i]);
		tot += k;
		cout <<k<<" ";
	}
	cout << tot << endl;
}
void Zseries24()
{
	int N, k1 = 0, k2 = 0, tot = 0;
	cin >> N;
	int a[100];
	for (int i = 0; i < N; i++)
	{
		cin >> a[i];
		if (a[i] == 0) {
			k1 = k2;
			k2 = i;
		}
	}
	for (int i = k1; i < k2; i++) tot += a[i];
	cout << tot << endl;
}
//zseries36
void Zminmax7()
{
	int N, k1 = 0, k2 = 0, max = -10000, min = 10000;
	cin >> N;
	int a[100];
	for (int i = 0; i < N; i++)
	{
		cin >> a[i];
		if (a[i]>max) {
			max = a[i];
			k1 = i;
		}
		if (a[i] <= min) {
			min = a[i];
			k2 = i;
		}
	}
	
	cout << k1 << " " << max << endl;
	cout << k2 << " " << min << endl;
}
void Zminmax13()
{
	int N, k1 = -1, max = -10000;
	cin >> N;
	int a[100];
	for (int i = 0; i < N; i++)
	{
		cin >> a[i];
		if ((a[i]%2==1)&&(a[i] > max)) {
			max = a[i];
			k1 = i;
		}
	}
	cout << k1 << endl;

}
void Zminmax24()
{
	int N, max = -10000;
	cin >> N;
	int a[100];
	for (int i = 0; i < N; i++)	cin >> a[i];
	for (int i = 0; i < N-1; i++)
	{
		int k = a[i] + a[i + 1];
		if (k > max) max = k;
	}
	cout << max << endl;
}
void ZArray3()
{
	int N, A, D;
	cin >> N >> A >> D;
	for (int i = 0; i < N; i++)
	{
		cout << A<<" ";
		A += D;
	}
}

void ZMatrix32()
{	cout << "\n//ZMatrix32\n" << endl;
	int m, n, a[200][200];
	cin >> m>> n;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)cin >> a[i][j];
	int line = -1;
	for (int i = 0; i < n; i++)
	{
		int postive = 0;
		int negtive = 0;
		for (int j = 0; j < m; j++)
			if (a[j][i] > 0) postive++;
			else if (a[j][i] < 0) negtive++;
		if (postive == negtive) line = n;
	}
	cout << line << " ";
}
void ZMatrix69()
{
	cout << "\n//ZMatrix69\n" << endl;
	int m, n, k;
	int a[200][200];
	cin >> n >> m;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)cin >> a[i][j];
	cin >> k;
	for (int i = n; i > k; i--)
		for (int j = 0; j < m; j++) a[j][i] = a[j][i - 1];
	for (int j = 0; j < m; j++) a[j][k + 1] = 1;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j <= n; j++) cout << a[i][j] << " ";
		cout << endl;
	}

}
void ZMatrix78()
{
	cout << "\n//ZMatrix78\n" << endl;
	int a[200][200], m, n;
	cin >> m >> n;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++) cin >> a[i][j];
	for (int i = 0; i < m - 1; i++)
		for (int j = i; j < m; j++)
		{
			if (a[i][0] < a[j][0])
			{
				for (int k = 0; k < n; k++) swap(a[i][k], a[j][k]);
			}
		}

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++) cout << a[i][j] << " ";
		cout << endl;
	}

}

void ZMatrix95()
{
	cout << "\n//ZMatrix95\n" << endl;
	int m, a[200][200];
	cin >> m;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < m; j++)cin >> a[i][j];
	for (int i = 0; i < m; i++)
		for (int j = 0; j <= min(i, m - i - 1); j++)
			a[i][j] = 0;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < m; j++) cout << a[i][j] << " ";
		cout << endl;
	}
}
int main()
{

	return 0;
}