#include "pt4.h"
using namespace std;

void fun(PNode &p){
    if(p->Left){
        fun(p->Left);
    }
    if(p->Right){
        fun(p->Right);
    }
    if(!p->Left && !p->Right){
        p->Left = new TNode;
        p->Left->Data = 10;
        p->Left->Left = nullptr;
        p->Left->Right = nullptr;
        p->Right = new TNode;
        p->Right->Data = 11;
        p->Right->Left = nullptr;
        p->Right->Right = nullptr;
    }
}

void Solve()
{
    Task("Tree44");
    PNode p1;
    pt>>p1;
    fun(p1);

}
