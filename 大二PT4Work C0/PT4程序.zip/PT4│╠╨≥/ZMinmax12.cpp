#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZMinmax12");
{
	int n;
	double iMin = 0;
	pt >> n;
	
	for (int i=0; i<n; i++)
	{
		double elem;
		pt >> elem;
		if (elem > 0)
		{
			if (iMin == 0)
			{
				iMin = elem;
			}
			else
			{
				if (elem < iMin)
					iMin = elem;
			}
		}
	}
	pt << iMin;
}
}
