#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZMatrix96");
    int m;
    float a[105][105];
    pt>>m;
    for(int i=0;i<m;i++){
        for(int j=0;j<m;j++){
            pt>>a[i][j];

 }
}
for(int i=0;i<m;i++){
for(int j=0;j<m;j++){
pt<<a[j][i];

 }
}
}
