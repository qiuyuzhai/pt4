#include "pt4.h"
using namespace std;

int NodeCount(PNode root)
{
    if(root==NULL)
    return 0;
    if(root->Left==NULL&&root->Right==NULL)
    return root->Data;
    return root->Data+NodeCount(root->Left)+NodeCount(root->Right);
}
void Solve()
{
    Task("Tree4");
    pt<<NodeCount(GetNode());

}
