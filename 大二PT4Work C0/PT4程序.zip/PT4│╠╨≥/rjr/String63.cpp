#include "pt4.h"
using namespace std;

void Solve()
{
    Task("String63");
    char s[100];
    int k;
    pt>>s;
    //int k;
    pt>>k;
    int n=strlen(s);
    for(int i=0;i<n;i++){
        if(s[i]>=65&&s[i]<=90-k||s[i]>=97&&s[i]<=122-k){
            s[i]+=k;
        }else{
            if(s[i]>=90-k&&s[i]<=90)
            {
                int y=90-s[i];
                s[i]=65+k-y;
                if(s[i]>=122-k&&s[i]<=122)
                {
                    int q=122-s[i];
                    s[i]=97+k-q-1;
                }
            }
       }
    pt<<s;
}
}

