#include "pt4.h"
using namespace std;

void Solve()
{
    Task("Dynamic14");
    PNode p2,p3;
    p2=p3=new TNode;
    pt>>p3->Data;
    for(int m=0;m<9;m++)
    {
    TNode*p1=new TNode;
    pt>>p1->Data;
    p3->Next=p1;
    p3=p1;
    }
    p3->Next=NULL;
    pt<<p2<<p3;

}