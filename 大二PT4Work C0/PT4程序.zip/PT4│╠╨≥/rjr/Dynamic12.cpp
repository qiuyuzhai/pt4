#include "pt4.h"
using namespace std;
struct TS
{
 PNode t;
};
void Pop(TS& a)
{
    PNode tmp = a.t;
    a.t = a.t->Next;
    pt << tmp->Data;
    delete tmp;
}

void Solve()
{
    Task("Dynamic12");
    TS a;
    pt>>a.t;
    for(int m=0;m<5;m++)
    {
    	
    	Pop(a);
	}
	pt<<a.t;

}
