#include "pt4.h"
using namespace std;

int a;
void fun(PNode p1)
{
	if (!p1)
		return;
	if (p1->Left || p1->Right)
		if (p1->Data > a)
			a = p1->Data;
	fun(p1->Left);
	fun(p1->Right);
}

void Solve()
{
	Task("Tree22");
	PNode p1;
	pt >> p1;
	a = p1->Data;
	fun(p1->Left);
	fun(p1->Right);
	pt << a;
}
