#include "pt4.h"
using namespace std;

void Solve()
{
    Task("String28");
	char c;
	pt>>c;
	char s1[50]={0};
	pt>>s1;
	char s2[50]={0};
	int a = 0;

	for (int m = 0; s1[m] != '\0'; m++) {

		s2[m + a] = s1[m];

		if (s1[m] == c) {
			a = a + 1;
			s2[m + a] = s1[m];
		}
	}

	pt<<s2;
}
