#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray1");
    int N;
    pt>>N;
    int i,n=0;
	do
	{
		i=2*n+1;
		n=n+1;
		pt<<i;
	}while(n<N);
  
}