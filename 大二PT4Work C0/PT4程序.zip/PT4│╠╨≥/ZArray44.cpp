#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray44");
{
	int n;
	int arr[100];

	pt >> n;
	for (int x=0; x<n; x++)
	{
		pt >> arr[x];
	}

	int i,j;
	for (i=0; i<n; i++)
	{
		int flag = 0;
		for (j=0; j<n; j++)
		{
			if (arr[i] == arr[j] && i!=j)
			{
				flag = 1;
				break;
			}
			
		}
		if (1 == flag)
			break;
	}
	if (i < j)
	{
		pt << i << j;
	}
	else
		pt << j << i;
}
}
