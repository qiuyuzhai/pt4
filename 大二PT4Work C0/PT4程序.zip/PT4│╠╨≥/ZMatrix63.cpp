#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZMatrix63");
float arr[100][100];
	int M ,N;
	pt >> M;
	pt >> N;

	for (int i=0; i<M; i++)
	{
		for (int j=0; j<N; j++)
		{
			pt >> arr[i][j];
		}
	}

	float fMin = arr[0][0];
	int iMin = 0;
	for (int i=0; i<M; i++)
	{
		for (int j=0; j<N; j++)
		{
			if (fMin > arr[i][j])
			{
				fMin = arr[i][j];
				iMin = i;
			}
		}
	}

	for (int i=0; i<M; i++)
	{
		if (i == iMin)
			continue;
		for (int j=0; j<N; j++)
		{
			

			pt << arr[i][j];
		}

	}


}
