#include "pt4.h"
#include <iostream>
#include <iomanip>
using namespace std;
void Minmax(double &x, double &y)
{
	if (x > y)
	{
		double tmp = x;
		x = y;
		y = tmp;
	}
}


void Solve()
{
    Task("XFunc32");
	
	double a,b,c,d;
	
	pt >> a >> b >> c >> d;

	Minmax(a,b);
	Minmax(c,d);
	Minmax(a,c);
	Minmax(b,d);

	pt << a;
	pt  << d;
}