#include "pt4.h"
#include"fstream"
using namespace std;
void Solve()
{
    Task("Text51");
    ifstream f(GetString());
    ofstream f1(GetString(), ios::binary);
    ofstream f2(GetString(), ios::binary);
    ofstream f3(GetString(), ios::binary);
    string s;
    int k=1;
    while (true)
    {
        
        double a;
        f >> a;
        if (f.eof())
            break;
        if(k==1){
            f1.write ((char *)&a,8);
            k=2;
        }else{
            if(k==2){
                f2.write ((char *)&a,8);
                k=3;
            }else{
                f3.write ((char *)&a,8);
                k=1;
            }
        }
    }
f.close();
}
