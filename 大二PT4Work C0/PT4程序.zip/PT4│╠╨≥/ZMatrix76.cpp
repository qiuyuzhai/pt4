#include "pt4.h"
#include <iostream>
#include<iomanip>
using namespace std;

void Solve()
{
    Task("ZMatrix76");
float res[100] = { 0 };
	float arr[100][100];
	int M, N;
	pt >> M;
	pt >> N;

	for (int i = 0; i < M; i++)
	{
		for (int j = 0; j < N; j++)
		{
			pt >> arr[i][j];
		}
	}
	
	for (int i = 0; i < M - 1; i++)
	{
		for (int j = 0; j < M- i - 1; j++)
		{
			if (arr[j][0] > arr[j + 1][0])
			{
				swap(arr[j], arr[j + 1]);
			}
		}
		
	}

	for (int i = 0; i < M; i++)
	{
		for (int j = 0; j < N; j++)
		{
			pt << arr[i][j];
		}
	}

}
