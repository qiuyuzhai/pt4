#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray59");
    int n;
    pt>>n;
    double a[n],b[n];
    for(int i=0;i<n;i++){
        pt>>a[i];
    }
    int k=1;
 
    for(int i=0;i<n;i++){
        double s=0.00;
        for(int j=0;j<k;j++){
           s+=a[j];
        }
        b[i]=s/k;
        pt<<b[i];
        k++;
}


}
