#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZMatrix40");
int m, n;
pt >> m >> n;
int a[m][n];
for (int i = 0; i < m; i++){
for (int j = 0; j < n; j++){
pt >> a[i][j];
}
}
int j,l,t,max,b[m];
for (int y = 0; y < m; y++){
max=1;
for (int w = 0; w < n; w++){
j=l=a[y][w];
t=0;
for(int q=0;q<n;q++){
if(a[y][q]==j){
t+=1;
if(t>max){
max=t;
 l=a[y][q];
}
}
}
}b[y]=max;
}
int ml,w=0;
ml=b[0];
for (int y = 1; y < m; y++){
if(b[y]>=ml){
ml=b[y];
w=y;
 }
}
pt<<w;



}
