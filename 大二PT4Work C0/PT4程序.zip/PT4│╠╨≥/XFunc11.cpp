#include "pt4.h"
#include<math.h>
using namespace std;

bool IsPower5(int K)
{
    double a=5;
    double b=0;
    while(pow(a,b)<K)
    b++;
    if(pow(a,b)==K)
    return true;
    else
    return false;
}

void Solve()
{
    Task("XFunc11");
    int c=0;
    for(int i=0;i<10;i++)
    {
        int K;
        pt>>K;
        if(IsPower5(K))
        c++;
    }
    pt<<c;
}
