#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray30");
{
	int n;
	double arr[100];

	pt >> n;
	for (int x=0; x<n; x++)
	{
		pt >> arr[x];
	}

	int num = 0;
	for (int i=0; i<n-1; i++)
	{
		if (arr[i] > arr[i+1])
		{
			pt << i;
			num++;
		}
	}
	pt << num;
	

}
}
