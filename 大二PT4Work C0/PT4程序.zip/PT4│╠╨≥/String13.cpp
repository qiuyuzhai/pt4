#include "pt4.h"
using namespace std;

void Solve()
{
    Task("String13");
	string str;
	int count = 0;
	pt >> str;
	for (int i = 0; i < str.size(); i++)
	{
		if (str[i] >= '0' && str[i] <= '9')
			count++;
	}
	pt << count;

}


