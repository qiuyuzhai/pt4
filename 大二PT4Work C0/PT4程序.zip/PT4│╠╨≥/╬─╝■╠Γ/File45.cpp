#include <cstdio>
#include <fstream>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

int main(){
    string s1,s2,s3;
    ifstream in;
    ofstream out;
    cin >> s1 >> s2 >> s3;
    vector<double> vec1;
    vector<double> vec2;
    vector<double> vec3;
    in.open(s1,ios::in);
    double num = 0;
    while(in >> num){
        vec1.push_back(num);
    }
    in.close();
    in.open(s2,ios::in);
    while(in >> num){
        vec2.push_back(num);
    }
    in.close();
    in.open(s3,ios::in);
    while(in >> num){
        vec3.push_back(num);
    }
    in.close();
    int n1 = vec1.size(),n2 = vec2.size(),n3 = vec3.size();
    vector<double> *maxx;
    string mins;
    if(n1 > n2 && n1 > n3){          
        maxx = &vec1;
    }
    else if (n2 > n1 && n2 > n3){
        maxx = &vec2;
    }
    else if (n3 > n1 && n3 > n2){
        maxx = &vec3;
    }
    
    if(n1 < n2 && n1 < n3){          //min
        mins = s1;
    }
    else if (n2 < n1 && n2 < n3){
        mins = s2;
    }
    else if (n3 < n1 && n3 < n2){
        mins = s3;
    }
    out.open(mins,ios::out);
    for(int i = 0;i < maxx->size();i++){
        out << (*maxx)[i] << " ";
    }
    out.close();
    return 0;
}