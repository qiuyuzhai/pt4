#include <cstdio>
#include <fstream>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

int main(){
    string s1,s2,s3;
    ifstream in;
    ofstream out;
    cin >> s1 >> s2 >> s3;
    vector<double> vec1;
    vector<double> vec2;
    vector<double> vec3;
    in.open(s1,ios::in);
    double num = 0;
    while(in >> num){
        vec1.push_back(num);
    }
    in.close();
    in.open(s2,ios::in);
    while(in >> num){
        vec2.push_back(num);
    }
    in.close();

    int i1 = 0,i2 = 0;
    while(i1 < vec1.size() || i2 < vec2.size()){
        double num1 = vec1[i1];
        double num2 = vec2[i2];
        if(i1 == vec1.size()){
            i2++;
            vec3.push_back(num2);
        }else if(i2 == vec2.size()){
            i1++;
            vec3.push_back(num1);
        }else if(num1 <= num2){
            i1++;
            vec3.push_back(num1);
        }else{
            i2++;
            vec3.push_back(num2);
        }
    }

    out.open(s3,ios::out);
    for(int i = 0;i < vec3.size();i++){
        out << vec3[i] << " ";
    }
    out.close();
    return 0;
}