#include <cstdio>
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

bool check(char c){
    if(c!=':'&& c!='/'&& c!='\\' && c!='"'&& c!='*'&& c!='?'&& c!='<'&& c!='>'&& c!='|')
        return true;
    return false;

}

int main(){
    string s;
    ofstream of;
    freopen("./test.in","r",stdin);
    cin >> s;
    for(int i = 0;i < s.length();i++){
        if(!check(i)){
            cout << "false" << endl;
            return 0;
        }
    }
    of.open(s,ios::out|ios::app);
    if(of.is_open())
        cout << "true" << endl;
    else
        cout << "false" << endl;
    return 0;
}