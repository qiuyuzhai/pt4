#include <cstdio>
#include <fstream>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

int main(){
    string s1,s2;
    ifstream in;
    ofstream out;
    cin >> s1 >> s2;
    in.open(s1,ios::in);
    vector<string> vec;
    string s;
    int maxx = 0;
    while(in >> s){
        if(s.length() >= maxx){
            maxx = s.length();
            vec.push_back(string(s));
        }
    }
    in.close();
    out.open(s2,ios::out);
    for(int i = vec.size()-1;i >= 0;i--){
        if(vec[i].length() == maxx){
            out << vec[i] << endl;
        }
    }
    out.close();
    return 0;
}