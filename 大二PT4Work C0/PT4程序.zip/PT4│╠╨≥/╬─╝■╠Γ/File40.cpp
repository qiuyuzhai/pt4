#include <cstdio>
#include <fstream>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

int main(){
    string s;
    ifstream in;
    ofstream out;
    cin >> s;
    in.open(s,ios::in);
    vector<int> vec;
    int n = 0;
    int num = 0;
    while(in >> num){
        vec.push_back(num);
    }
    in.close();
    out.open(s,ios::out);
    for(int i = 0;i < vec.size();i++){
        if((i+1) & 1)
            out << vec[i] << " ";
        else
            out << "0 0 ";
    }
    out.close();
    return 0;
}