#include <cstdio>
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

int main(){
    string s;
    ifstream in;
    cin >> s;
    in.open(s,ios::in); //打开给的文件
    double num;
    double sum = 0;
    for(int i = 1;in >> num;i++){
        if(i & 1)
            continue;
        sum += num;
    }
    cout << sum << endl;
    return 0;
}