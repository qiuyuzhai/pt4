#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray105");
{
	int n;
	double a[100];
	pt >> n;
	for (int i=0; i<n; i++)
	{
		double elem;
		pt >> elem;
		a[i] = elem;
	}
	int k,m;
	pt >> k;
	pt >> m;

	for (int i=0; i<=k; i++)
	{
		pt << a[i];
	}

	for (int x=0; x<m; x++)
	{
		double elem = 0.0f;
		pt << elem;
	}
	for (int i=k+1; i<n; i++)
	{
		pt << a[i];
	}
}
}

