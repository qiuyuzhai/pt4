N = int(input())
mx = -1e9+7
pos = -1
for i in range(1,N+1):
    temp = int(input())
    if temp %2 == 0 : 
        continue
    if temp > mx :
        mx = temp
        pos = i
        continue
print(pos)

