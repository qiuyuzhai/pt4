#include "pt4.h"
#include <iostream>
#include <fstream>
using namespace std;

void Solve()
{
    Task("Text3");
	int n;
	string name;
	ofstream file;
	pt >> name;
	pt >> n;
	file.open(name);
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j <= i; j++)
		{
			file << (char)('A' + j);
		}
		for (int j = n - i - 1; j > 0; j--)
		{
			file << '*';
		}
		file<<endl;
	}
	file.close();
}
