#include "pt4.h"
#include <iostream>
using namespace std;

void Solve()
{
    Task("ZSeries14");
{
	int k;
	int i = 0;
	pt >> k;
	while (1)
	{
		int n;
		pt >> n;
		if (n == 0)
		{
			break;
		}
		if (n<k)
			i++;
	}
	pt << i;

}
}
