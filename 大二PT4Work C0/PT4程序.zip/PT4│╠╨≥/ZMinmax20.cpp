#include "pt4.h"
#include <iostream>
using namespace std;

void Solve()
{
    Task("ZMinmax20");
{
	int n;
	int iMin;
	int iMax;
	int a[100];
	int flag = 0;
	pt >> n;
	
	for (int i=0; i<n; i++)
	{
		int elem;
		pt >> elem;
		if (flag == 0)
		{
			flag = 1;
			iMax = elem;
			iMin = elem;
		}
		else
		{
			if (elem > iMax)
			{
				iMax = elem;
			}
			if (elem < iMin)
			{
				iMin = elem;
			}
		}
		a[i] = elem;
	}

	int num = 0;
	for (int i=0; i<n; i++)
	{
		if (a[i]== iMin || a[i]==iMax)
		{
			num++;
		}
	}
	pt << num;
}
}