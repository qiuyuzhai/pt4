#include "pt4.h"
#include <iostream>
#include <iomanip>
using namespace std;
double Fact2(int n)
{
	int ret = 1;
	if (n % 2 == 0)
	{
		for (int i = 2; i <= n; i += 2)
		{
			ret *= i;
		}
	}
	else
	{
		for (int i = 1; i <= n; i += 2)
		{
			ret *= i;
		}
	}
    return ret;
}
void Solve( )
{
    Task("Recur2");
	int a,b,c,d,e;
    pt >> a >> b >> c >> d >> e;
    pt << Fact2(a);
    pt << Fact2(b);
    pt << Fact2(c);
    pt << Fact2(d);
    pt << Fact2(e);
}


