#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray114");
    int n;
    pt>>n;
    double a[n],k;
    for(int i=0;i<n;i++){
        pt>>a[i];
    }

    int i,j;
    for (i=1;i<n;i++){
        k = a[i];
        j=i-1;
        while((j>=0) && (a[j]>k)) {
            a[j+1] = a[j];
            j--;
            }
        a[j+1] = k;
        for(int i=0;i<n;i++){
        pt<<a[i];
    }
    }

}