#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZMatrix58");
float arr[100][100];
	int M ,N;
	pt >> M;
	pt >> N;

	for (int i=0; i<M; i++)
	{
		for (int j=0; j<N; j++)
		{
			pt >> arr[i][j];
		}
	}

	for (int i=0; i<M; i++)
	{
		for (int j=0; j<N; j++)
		{
			int x = M/2;
			int y = N/2;
			if (i<x && j>=y)
			{
				float tmp = arr[i][j];
				arr[i][j] = arr[i + x][j-y];
				arr[i + x][j-y] = tmp;
			}
		}
	}

	for (int i=0; i<M; i++)
	{
		for (int j=0; j<N; j++)
		{
			pt << arr[i][j];
		}

	}
}


