#include "pt4.h"
using namespace std;

void Solve()
{
    Task("String12");
string s;
int n;
pt>>s>>n;
string delim(n,'*');
Show(delim);
for(int i=s.length()-1;i>=1;i--)
{
    s.insert(i,delim);
    ShowLine(s);
}
pt<<s;
}
