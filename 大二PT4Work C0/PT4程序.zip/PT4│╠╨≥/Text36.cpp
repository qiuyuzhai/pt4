#include "pt4.h"
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

string res[1000];
void Solve()
{
    Task("Text36");
	int i = 0;
	string s;
	string name;
	ifstream ifile;
	ofstream ofile;
	pt >> name;
	ifile.open(name);
	while (getline(ifile, s))
	{
		int count = 0;
		for (int i = 0; i < s.size(); i++)
		{
			if (s[i] == ' ')
				count++;
			else
				break;
		}
		if (count % 2 == 0)
			s.erase(0, count / 2);
		else
			s.erase(0, (count + 1) / 2);
		res[i] = s;
		i++;
	}
	ofile.open(name);
	for (int j = 0; j < i; j++)
	{
		ofile << res[j]<<endl;
	}
	ofile.close();
}
