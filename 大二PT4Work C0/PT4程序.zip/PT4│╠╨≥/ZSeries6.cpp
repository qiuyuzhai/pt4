
#include "pt4.h"
#include <iostream>
#include <iomanip>
using namespace std;


void Solve()
{
    Task("ZSeries6");
{

	double a[100];
	int N;
	pt >> N;

	for (int i=0; i<N; i++)
	{
		pt >> a[i];
	}
	double sum = 1.0f;
	double elem;
	for (int i=0; i<N; i++)
	{
		elem = a[i] - (int)a[i];
		pt  << elem;
		sum *= elem;
	}
	pt <<  sum ;

}
}