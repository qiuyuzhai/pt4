#include "pt4.h"
#include<fstream>
using namespace std;

int n;
ofstream f;
string s;

void Step(int n0,char k0,int w,int wsum)
{
    s+=k0;
    wsum+=w;
    if(n0==n)
    {
        if(wsum==0)
        f<<s<<endl;
    }
    else
    {
        Step(n0+1,'A',1,wsum);
        Step(n0+1,'B',-1,wsum);        
    }
    s.erase(s.length()-1);
}

void Solve()
{
    Task("Recur27");
string name;
pt>>n>>name;
f.open(name);
s="";
Step(0,'C', 0, 0);
f.close();
}
