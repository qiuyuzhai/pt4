# temp_str = input("input:");
# print(temp_str)

'''
String 3。 给定一个字符 C。输出两个字符，第一个字符在码表中字符 C 之前，第二个字符在字符 C 之后。
'''
def test_03():
    print("请输入一个字符:")
    temp_str = input("")
    index = ord(temp_str)
 #   print(index)
    print("前一个字符为："+chr(index-1))
    print("后一个字符串："+chr(index+1))


'''
string 11。 给定一个非空字符串 S在每个字符中间插入一个空格，输出一个包含字符串 S 的字符串
'''    
def test_string_11():
    print("请给出一个非空字符串")
    temp_str = input("")
    
    print(temp_str)

    d=list(temp_str)
    temp_str_length = len(d)
    print(temp_str_length)

    target_str = ''
    for i in range(0,temp_str_length-1):
        #print(i)
        target_str = target_str + d[i] + " "
    print(target_str+d[temp_str_length-1])

'''

string 22 给定一个正整数的字符串。 打印这个字符串中的数字总和
''' 
def test_string_22():
    print("请给出一个正整数的字符串")
    temp_str = input("")
    d=list(temp_str)    
    result = 0
    for i in d:
        result = result + int(i)
    print(result)
    
'''    
string 28。 给定一个字符 C 和一个字符串 S。将字符串 S 中出现的字符 C 加倍。
'''
def test_string_28():
        print("请输入一个字符")
        temp_char = input("")        
        print("请输入字符串")
        temp_str = input("")
        d = list(temp_str)
        result = ""
        for i in d:
            if temp_char == i :
                result = result + i + i
            else: 
                result = result + i
        print(result)
        
    
    
    
    
 
def main():
#    testAscii()
#    print("hello world")
#    test_03()
#     test_string_11()
#    test_string_22()
     test_string_28()
    

if __name__ == "__main__":
        main()
        
        
        