#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray82");
    int n, k;
    pt >> n;
    float a[n];
    for (int i = 0; i < n; i++)
        pt >> a[i];
    pt >> k;
    for (int i = 0; i < n - k; ++i)
        a[i] = a[i + k];
    for (int i = n - k; i < n; ++i)
        a[i] = 0;
    for (int i = 0; i < n; i++)
        pt << a[i];
}
