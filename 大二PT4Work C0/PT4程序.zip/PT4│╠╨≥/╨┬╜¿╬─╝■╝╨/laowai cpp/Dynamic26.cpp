#include "pt4.h"
using namespace std;

class IntQueue
{
    public:
        PNode Head;
        PNode Tail;
        IntQueue(PNode head, PNode tail) : Head(tail), Tail(head) {}
        void Put() { pt << Head << Tail; };
        void Sshow() {Show(Head->Data); Show(Tail->Data);}
        void Enqueue(int d);
};

void IntQueue::Enqueue(int d)
{
    PNode temp = new TNode;
    temp->Next = NULL;
    temp->Data = d;
    if (Tail != NULL)
        Tail->Next = temp;
    else
        Head = temp;
    Tail = temp;
}


void Solve()
{
    Task("Dynamic26");
    IntQueue q(GetNode(), GetNode());
    int n =  GetInt();
    q.Sshow();
    for (int i = 0; i < n; i++)
    {
        Show(i);
        q.Enqueue(GetInt());
    }
    q.Put();
}
