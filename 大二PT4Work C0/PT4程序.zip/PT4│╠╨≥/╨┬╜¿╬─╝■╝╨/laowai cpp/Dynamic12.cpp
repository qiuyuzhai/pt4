#include "pt4.h"
using namespace std;

struct TStack
{
    PNode Top;
};

void Push(TStack& s, int d)
{
    PNode p = new TNode;
    p->Data = d;
    p->Next = s.Top;
    s.Top = p;
}

int Pop(TStack& s)
{
    PNode p = s.Top;
    s.Top = s.Top->Next;
    int x = p->Data;
    delete(p);
    return x;
}


void Solve()
{
    Task("Dynamic12");
    TStack s;
    int n = 5;
    pt >> s.Top;
    for (int i = 0; i < n; i++)
    {
        pt << Pop(s);
    }
    pt << s.Top;
}
