#include "pt4.h"
#include <iostream>
#include <string>
using namespace std;

void Solve()
{
    Task("String11");
    string s = GetString();
    string delim(1, ' ');
    for (int i = s.length() - 1; i >= 1; i--)
        s.insert(i, delim);
    pt << s;
}
