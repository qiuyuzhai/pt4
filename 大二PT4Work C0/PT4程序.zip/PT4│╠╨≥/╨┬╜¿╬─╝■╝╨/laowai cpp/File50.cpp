#include "pt4.h"
#include <fstream>
#include <string>
using namespace std;

void Solve()
{
    Task("File50");
    fstream *f = new fstream[3];
    string name1 = GetString(), name2 = GetString(), name3 = GetString();
    f[0].open(name1.c_str(), ios::binary | ios::in);
    f[1].open(name2.c_str(), ios::binary | ios::in);
    f[2].open(name3.c_str(), ios::binary | ios::out);

    double x1, x2;
    f[0].read((char *)&x1, sizeof(x1));
    f[1].read((char *)&x2, sizeof(x2));
   // while ((f[0].peek() != EOF) or (f[1].peek() != EOF))
   //========================
    double BigValue = 10000;
    while (x1 != BigValue || x2 != BigValue)
   //======================== 
    {
        if (x1 < x2)
        {
            f[2].write((char *)&x1, sizeof(x1));
            //===============
            if (f[0].peek() == EOF)  
              x1 = BigValue;
            else  
            //=================
            f[0].read((char *)&x1, sizeof(x1));
        }
        else
        {
            f[2].write((char *)&x2, sizeof(x2));
            //===============
            if (f[1].peek() == EOF)  
              x2 = BigValue;
            else  
            //=================            
            f[1].read((char *)&x2, sizeof(x2));
        }
    }
    Show(x1);
    Show(x2);
    // if (f[0].peek() == EOF)
    // {
    //     if (x1 > x2)
    //     {
    //         while ((f[1].peek() != EOF) and (x1 > x2))
    //         {
    //             f[2].write((char *)&x2, sizeof(x2));
    //             f[1].read((char *)&x2, sizeof(x2));
    //         }
    //         if (x1 > x2)
    //         {
    //             f[2].write((char *)&x2, sizeof(x2));
    //             f[2].write((char *)&x1, sizeof(x1));
    //         }
    //         else
    //         {
    //             f[2].write((char *)&x1, sizeof(x1));
    //             while (f[1].peek() != EOF)
    //             {
    //                 f[0].read((char *)&x2, sizeof(x2));
    //                 f[2].write((char *)&x2, sizeof(x2));
    //             }
    //         }
    //     }
    //     else
    //         {
    //             f[2].write((char *)&x1, sizeof(x1));
    //             f[2].write((char *)&x2, sizeof(x2));
    //             while (f[1].peek() != EOF)
    //             {
    //                 f[1].read((char *)&x2, sizeof(x2));
    //                 f[2].write((char *)&x2, sizeof(x2));
    //             }
    //         }
    // }  
    // else if (f[1].peek() == EOF)
    // {
    //     if (x1 < x2)
    //     {
    //         while ((f[0].peek() != EOF) and (x1 < x2))
    //         {
    //             f[2].write((char *)&x1, sizeof(x1));
    //             f[1].read((char *)&x1, sizeof(x1));
    //             Show(x1);
    //         }
    //         if (x1 < x2)
    //         {
    //             f[2].write((char *)&x1, sizeof(x1));
    //             f[2].write((char *)&x2, sizeof(x2));
    //         }
    //         else
    //         {
    //             f[2].write((char *)&x2, sizeof(x2));
    //             while (f[0].peek() != EOF)
    //             {
    //                 f[0].read((char *)&x1, sizeof(x1));
    //                 f[2].write((char *)&x1, sizeof(x1));
    //             }
    //         }
    //     }
    //     else
    //     {
    //         f[2].write((char *)&x2, sizeof(x2));
    //         f[2].write((char *)&x1, sizeof(x1));
    //         while (f[0].peek() != EOF)
    //         {
    //             f[0].read((char *)&x1, sizeof(x1));
    //             f[2].write((char *)&x1, sizeof(x1));
    //         }
    //     }
    // }
    for (int i = 0; i < 3; ++i)
        f[i].close();
}
