#include "pt4.h"
using namespace std;

void Solve()
{
    Task("ZArray130");
    int n; pt >> n;
    int a[2 * n], maxlen = 0, curlen = 1;
    pt >> a[0];
    for (int i = 1; i < n; i++)
    {
        pt >> a[i];
        if (a[i] == a[i - 1]) curlen++;
        else 
        {
            if (curlen > maxlen) maxlen = curlen;
            curlen = 1;
        } 
    }
    if (curlen > maxlen) maxlen = curlen;
    int i = 1;
    curlen = 1;
    while (i < n)
    {
        if (a[i] == a[i - 1]) curlen ++;
        else if (curlen == maxlen)
        {
            int temp = a[i];
            a[i] = a[i-1];
            for (int j = i + 1; j <= n; j++)
            {
                int temp2 = a[j];
                a[j] = temp;
                temp = temp2;
            }
            curlen = 0;
            n++;
        }
        else curlen = 1;
        i++;
    }
    if (curlen == maxlen)
    {
        a[i] = a[i - 1];
        n++;
    } 
    for (int i = 0; i < n; i++) pt << a[i];

}
