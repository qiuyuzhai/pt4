#include "pt4.h"
using namespace std;

void Solve()
{
    Task("String68");
    string s = GetString();
    int res = 0, i = 0, prev = 0;
    bool inorder = true;
    while (i < s.length() and inorder)
    {
        if ((s[i] >= 97) and (s[i] <= 122))
        {
            inorder = (int) s[i] >= prev;
            prev = (int)s[i];
            if (not inorder)
                res = i + 1;
        }
        i++;
    }
    pt << res;
}
