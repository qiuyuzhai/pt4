#include "pt4.h"
#include <fstream>
#include <string> 
#include <iomanip>
using namespace std;

void Solve()
{
    Task("Text40");
    int a, b;
    string name1 = GetString(), name2 = GetString(), name3 = GetString();
    fstream *f = new fstream[2];
    f[0].open(name1.c_str(), ios::binary | ios::in);
    f[1].open(name2.c_str(), ios::binary | ios::in);
    ofstream res(name3);
    while (f[0].peek() != EOF)
    {
        f[0].read((char *)&a, sizeof(a));
        f[1].read((char *)&b, sizeof(b));
        Show(a);
        res << "|" << setw(30) << a << setw(30) << b << "|" << endl;
    }
    f[0].close(); 
    f[1].close(); 
    res.close();
}
