#include "pt4.h"
#include<fstream>
#include<iomanip>
#include<cmath>
using namespace std;

void Solve()
{
    Task("Text42");
    double a,b,h,x;
    int n;
    string name;
    pt>>a>>b>>n>>name;
    ofstream f(name);
    h=(b-a)/n;
    ShowLine(h);
    f<<fixed;
    for (int i = 0; i <=n; i++)
    {
       x=a+i*h;
       //Show(x);
       //ShowLine(sqrt(x));
       f<<setprecision(4)<<setw(10)<<x<<setprecision(8)<<setw(15)<<sqrt(x)<<endl;
    }
    

    f.close();
}
